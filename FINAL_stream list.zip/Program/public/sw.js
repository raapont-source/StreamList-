const CACHE_NAME = "streamlist-shell-v1";
const APP_SHELL = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/icons/icon-maskable-512.png",
];
const CACHEABLE_DESTINATIONS = new Set([
  "font",
  "image",
  "manifest",
  "script",
  "style",
]);

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      await cache.addAll(APP_SHELL);

      const index = await cache.match("/index.html");
      if (!index) throw new Error("The app entry page was not cached.");

      const html = await index.text();
      const assetPaths = Array.from(
        html.matchAll(/(?:src|href)="([^"]+\.(?:js|css))"/g),
        ([, assetPath]) => assetPath,
      );
      const sameOriginAssets = assetPaths.filter(
        (assetPath) =>
          new URL(assetPath, self.location.origin).origin === self.location.origin,
      );
      await cache.addAll(sameOriginAssets);
    })(),
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) =>
        Promise.all(
          cacheNames
            .filter(
              (cacheName) =>
                cacheName.startsWith("streamlist-") && cacheName !== CACHE_NAME,
            )
            .map((cacheName) => caches.delete(cacheName)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  if (
    request.method !== "GET" ||
    url.origin !== self.location.origin ||
    url.pathname.startsWith("/api/")
  ) {
    return;
  }

  if (request.mode === "navigate") {
    event.respondWith(
      (async () => {
        try {
          const response = await fetch(request);
          if (response.ok) {
            try {
              const cache = await caches.open(CACHE_NAME);
              await cache.put(request, response.clone());
            } catch (error) {
              console.error("Unable to cache the app page:", error);
            }
          }
          return response;
        } catch (error) {
          const cachedPage =
            (await caches.match(request)) ||
            (await caches.match("/")) ||
            (await caches.match("/index.html"));
          if (cachedPage) return cachedPage;
          throw error;
        }
      })(),
    );
    return;
  }

  if (!CACHEABLE_DESTINATIONS.has(request.destination)) return;

  event.respondWith(
    (async () => {
      try {
        const cachedResponse = await caches.match(request);
        if (cachedResponse) return cachedResponse;
      } catch (error) {
        console.error("Unable to read the app cache:", error);
      }

      const response = await fetch(request);
      if (response.ok && response.type === "basic") {
        try {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(request, response.clone());
        } catch (error) {
          console.error("Unable to cache an app resource:", error);
        }
      }
      return response;
    })(),
  );
});
