import { useEffect, useState } from "react";
import { Clapperboard, Search, Star, CalendarDays, ShoppingCart } from "lucide-react";

const API_KEY = import.meta.env.VITE_TMDB_API_KEY;
const API_BASE = "https://api.themoviedb.org/3";
const IMAGE_BASE = "https://image.tmdb.org/t/p/w500";
const RENTAL_PRICE = 3.99;

function Discover({ cartItems, onAddToCart }) {
  const [movies, setMovies] = useState([]);
  const [query, setQuery] = useState("");
  const [activeQuery, setActiveQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!API_KEY) {
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    const endpoint = activeQuery
      ? `${API_BASE}/search/movie?query=${encodeURIComponent(activeQuery)}`
      : `${API_BASE}/movie/popular`;

    async function loadMovies() {
      setLoading(true);
      setError("");

      try {
        const separator = endpoint.includes("?") ? "&" : "?";
        const response = await fetch(`${endpoint}${separator}api_key=${API_KEY}`, {
          signal: controller.signal,
        });

        if (!response.ok) {
          throw new Error(
            response.status === 401
              ? "TMDB rejected the API key. Check your VITE_TMDB_API_KEY value."
              : `TMDB request failed (${response.status}). Please try again.`,
          );
        }

        const data = await response.json();
        setMovies(data.results ?? []);
      } catch (requestError) {
        if (requestError.name !== "AbortError") {
          setError(requestError.message || "Unable to load movies from TMDB.");
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    loadMovies();
    return () => controller.abort();
  }, [activeQuery]);

  function handleSearch(event) {
    event.preventDefault();
    setActiveQuery(query.trim());
  }

  return (
    <section className="page-card discover-page">
      <div className="page-heading">
        <Clapperboard size={34} />
        <div>
          <p className="eyebrow">POWERED BY TMDB</p>
          <h2>Discover Movies</h2>
          <p>Explore popular films or search the TMDB catalog.</p>
        </div>
      </div>

      <form className="discover-search" onSubmit={handleSearch}>
        <label className="sr-only" htmlFor="movie-search">Search movies</label>
        <input
          id="movie-search"
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search by movie title"
        />
        <button type="submit" aria-label="Search TMDB">
          <Search size={18} />
          Search
        </button>
      </form>

      <div className="discover-results-heading">
        <h3>{activeQuery ? `Results for “${activeQuery}”` : "Popular now"}</h3>
        <span>{loading ? "Loading" : `${movies.length} titles`}</span>
      </div>

      {!API_KEY ? (
        <p className="discover-message" role="status">
          Add your TMDB API key as <code>VITE_TMDB_API_KEY</code> in a local
          <code> .env</code> file, then restart the development server.
        </p>
      ) : loading ? (
        <p className="discover-message" role="status">Loading movies from TMDB...</p>
      ) : error ? (
        <p className="discover-message discover-error" role="alert">{error}</p>
      ) : movies.length === 0 ? (
        <p className="discover-message" role="status">No movies found. Try another title.</p>
      ) : (
        <div className="discover-grid">
          {movies.map((movie) => (
            <article className="discover-movie" key={movie.id}>
              {movie.poster_path ? (
                <img
                  className="discover-poster"
                  src={`${IMAGE_BASE}${movie.poster_path}`}
                  alt={`${movie.title} poster`}
                  loading="lazy"
                />
              ) : (
                <div className="discover-poster poster-placeholder" aria-label="No poster available">
                  <Clapperboard size={32} />
                  <span>No poster</span>
                </div>
              )}
              <div className="discover-movie-info">
                <h4>{movie.title}</h4>
                <div className="discover-meta">
                  {movie.release_date && (
                    <span><CalendarDays size={14} />{movie.release_date.slice(0, 4)}</span>
                  )}
                  <span><Star size={14} />{Number(movie.vote_average).toFixed(1)}</span>
                </div>
                <p>{movie.overview || "No overview available."}</p>
                <div className="discover-purchase">
                  <strong>${RENTAL_PRICE.toFixed(2)}</strong>
                  <button
                    type="button"
                    onClick={() =>
                      onAddToCart({
                        id: `tmdb-movie-${movie.id}`,
                        title: movie.title,
                        price: RENTAL_PRICE,
                        image: movie.poster_path
                          ? `${IMAGE_BASE}${movie.poster_path}`
                          : "",
                        year: movie.release_date?.slice(0, 4) || "",
                      })
                    }
                  >
                    <ShoppingCart size={16} />
                    {cartItems.some((item) => item.id === `tmdb-movie-${movie.id}`)
                      ? "Add another"
                      : "Add to cart"}
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      <p className="tmdb-attribution">Movie data and images courtesy of TMDB.</p>
    </section>
  );
}

export default Discover;