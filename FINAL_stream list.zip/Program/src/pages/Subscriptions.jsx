import { useState } from "react";
import { Check, Clapperboard, Crown, Film, Sparkles } from "lucide-react";

const plans = [
  {
    id: "plus",
    name: "Plus",
    price: "$9.99",
    cadence: "per month",
    description: "A little more room for movie nights.",
    features: ["Unlimited watch list", "HD streaming", "Cancel anytime"],
    Icon: Sparkles,
  },
  {
    id: "premier",
    name: "Premier",
    price: "$19.99",
    cadence: "per month",
    description: "The full-featured home theater plan.",
    features: ["Everything in Plus", "4K-ready catalog", "Up to 4 profiles"],
    Icon: Crown,
  },
  {
    id: "retro",
    name: "Retro",
    price: "$399.99",
    cadence: "per year",
    description: "One annual pass for the classics enthusiast.",
    features: ["Everything in Premier", "Curated retro picks", "Annual billing"],
    Icon: Film,
  },
];

function Subscriptions() {
  const [selectedPlan, setSelectedPlan] = useState("");

  return (
    <section className="page-card subscriptions-page">
      <div className="page-heading">
        <Clapperboard size={34} />
        <div>
          <p className="eyebrow">YOUR NEXT FEATURE</p>
          <h2>Subscriptions</h2>
          <p>Pick a plan for your movie nights.</p>
        </div>
      </div>

      <div className="plan-grid">
        {plans.map(({ id, name, price, cadence, description, features, Icon }) => (
          <article className={`subscription-plan plan-${id}`} key={id}>
            <div className="plan-title">
              <Icon size={22} aria-hidden="true" />
              <h3>{name}</h3>
            </div>
            <p className="plan-description">{description}</p>
            <p className="plan-price">
              <strong>{price}</strong>
              <span>{cadence}</span>
            </p>
            <ul>
              {features.map((feature) => (
                <li key={feature}><Check size={16} />{feature}</li>
              ))}
            </ul>
            <button
              type="button"
              className="plan-select"
              aria-pressed={selectedPlan === id}
              onClick={() => setSelectedPlan(id)}
            >
              {selectedPlan === id ? "Selected" : `Choose ${name}`}
            </button>
          </article>
        ))}
      </div>

      <p className="subscription-note" role="status">
        {selectedPlan
          ? `${plans.find((plan) => plan.id === selectedPlan).name} selected. Checkout is not connected yet.`
          : "Choose a plan to see your selection. Payments are not connected yet."}
      </p>
    </section>
  );
}

export default Subscriptions;
