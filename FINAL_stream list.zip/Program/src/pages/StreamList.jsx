import { useState } from "react";
import {
  Plus,
  Clapperboard,
  Pencil,
  Trash2,
  Check,
  Save,
  X,
} from "lucide-react";

function StreamList({
  movies,
  onAddMovie,
  onDeleteMovie,
  onToggleMovie,
  onRenameMovie,
}) {
  // Keeps track of what the user is typing
  const [title, setTitle] = useState("");

  // Keeps track of which movie is being edited
  const [editingId, setEditingId] = useState(null);

  // Keeps track of the new title while editing
  const [editTitle, setEditTitle] = useState("");

  // Add a movie to the list
  function handleSubmit(event) {
    event.preventDefault();

    const cleanedTitle = title.trim();

    // Do not add an empty movie
    if (cleanedTitle === "") {
      return;
    }

    const newMovie = {
      id: globalThis.crypto?.randomUUID?.() ?? Date.now(),
      title: cleanedTitle,
      completed: false,
      price: 0,
      mediaType: "manual",
    };

    onAddMovie(newMovie);

    // Clear the input after adding
    setTitle("");
  }

  // Start editing a movie
  function startEdit(movie) {
    setEditingId(movie.id);
    setEditTitle(movie.title);
  }

  // Save the edited movie
  function saveEdit(id) {
    const cleanedTitle = editTitle.trim();

    if (cleanedTitle === "") {
      return;
    }

    onRenameMovie(id, cleanedTitle);

    // Leave edit mode
    setEditingId(null);
    setEditTitle("");
  }

  // Cancel editing
  function cancelEdit() {
    setEditingId(null);
    setEditTitle("");
  }

  return (
    <section className="page-card">
      <div className="page-heading">
        <Clapperboard size={34} />

        <div>
          <p className="eyebrow">MY WATCH LIST</p>

          <h2>StreamList</h2>

          <p>
            Enter a movie or program you want to watch and add it to your
            personal StreamList.
          </p>
        </div>
      </div>

      {/* Add Movie Form */}
      <form className="stream-form" onSubmit={handleSubmit}>
        <label htmlFor="stream-title">Movie or program title</label>

        <div className="input-row">
          <input
            id="stream-title"
            type="text"
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Example: The Mandalorian"
          />

          <button type="submit">
            <Plus size={18} />
            Add to List
          </button>
        </div>
      </form>

      {/* Movie List */}
      <div className="movie-list-section">
        <h3>My StreamList</h3>

        {movies.length === 0 ? (
          <p className="empty-message">
            Your StreamList is empty. Add a movie or program above.
          </p>
        ) : (
          <div className="movie-list">
            {movies.map((movie) => (
              <div
                className={`movie-item ${
                  movie.completed ? "completed-movie" : ""
                }`}
                key={movie.id}
              >
                {/* Editing Mode */}
                {editingId === movie.id ? (
                  <div className="edit-area">
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(event) => setEditTitle(event.target.value)}
                    />

                    <button
                      type="button"
                      className="save-button"
                      onClick={() => saveEdit(movie.id)}
                    >
                      <Save size={17} />
                      Save
                    </button>

                    <button
                      type="button"
                      className="cancel-button"
                      onClick={cancelEdit}
                    >
                      <X size={17} />
                      Cancel
                    </button>
                  </div>
                ) : (
                  <>
                    {/* Movie Title */}
                    <div className="movie-info">
                      <span className="movie-title">{movie.title}</span>
                      <div className="movie-meta">
                        <span>{movie.mediaType === "tv" ? "TV show" : movie.mediaType === "movie" ? "Movie" : "Personal pick"}</span>
                        <strong>{movie.price > 0 ? `$${movie.price.toFixed(2)}` : "Free"}</strong>
                      </div>

                      {movie.completed && (
                        <span className="watched-label">
                          <Check size={16} />
                          Watched
                        </span>
                      )}
                    </div>

                    {/* Movie Buttons */}
                    <div className="movie-actions">
                      <button
                        type="button"
                        className="complete-button"
                        onClick={() => onToggleMovie(movie.id)}
                      >
                        <Check size={17} />

                        {movie.completed ? "Undo" : "Complete"}
                      </button>

                      <button
                        type="button"
                        className="edit-button"
                        onClick={() => startEdit(movie)}
                      >
                        <Pencil size={17} />
                        Edit
                      </button>

                      <button
                        type="button"
                        className="delete-button"
                        onClick={() => onDeleteMovie(movie.id)}
                      >
                        <Trash2 size={17} />
                        Delete
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

export default StreamList;