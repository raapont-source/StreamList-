import MediaCatalog from "../components/MediaCatalog";

function Shows({ streamListItems, onAddToStreamList }) {
  return (
    <MediaCatalog
      mediaType="tv"
      streamListItems={streamListItems}
      onAddToStreamList={onAddToStreamList}
    />
  );
}

export default Shows;
