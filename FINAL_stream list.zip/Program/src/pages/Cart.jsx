import { Link } from "react-router-dom";
import { ArrowRight, CreditCard, Minus, Plus, ShoppingCart, Trash2 } from "lucide-react";

const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
});

function Cart({ cartItems, onUpdateQuantity, onRemoveItem, onClearCart }) {
  const itemCount = cartItems.reduce((total, item) => total + item.quantity, 0);
  const total = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0,
  );

  return (
    <section className="page-card cart-page">
      <div className="page-heading cart-heading">
        <ShoppingCart size={34} />
        <div>
          <p className="eyebrow">YOUR ORDER</p>
          <h2>Cart</h2>
          <p>{itemCount} {itemCount === 1 ? "item" : "items"} in your collection</p>
        </div>
        {cartItems.length > 0 && (
          <button className="cart-clear" type="button" onClick={onClearCart}>
            <Trash2 size={16} />
            Clear cart
          </button>
        )}
      </div>

      {cartItems.length === 0 ? (
        <div className="cart-empty">
          <ShoppingCart size={42} aria-hidden="true" />
          <h3>Your cart is waiting for a feature.</h3>
          <p>Find a movie to rent and it will be kept here for your next visit.</p>
          <Link className="cart-browse" to="/discover">
            Browse movies <ArrowRight size={17} />
          </Link>
        </div>
      ) : (
        <div className="cart-layout">
          <div className="cart-items" aria-label="Cart items">
            {cartItems.map((item) => (
              <article className="cart-item" key={item.id}>
                {item.image ? (
                  <img className="cart-item-image" src={item.image} alt="" />
                ) : (
                  <div className="cart-item-image cart-image-placeholder">
                    <ShoppingCart size={24} />
                  </div>
                )}
                <div className="cart-item-details">
                  <h3>{item.title}</h3>
                  <p>{item.year ? `${item.year} · ` : ""}Digital rental</p>
                  <strong>{currency.format(item.price)} each</strong>
                </div>
                <div className="cart-item-controls">
                  <div className="quantity-control" aria-label={`Quantity for ${item.title}`}>
                    <button
                      type="button"
                      aria-label={`Decrease ${item.title} quantity`}
                      disabled={item.quantity <= 1}
                      onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                    >
                      <Minus size={15} />
                    </button>
                    <span aria-live="polite">{item.quantity}</span>
                    <button
                      type="button"
                      aria-label={`Increase ${item.title} quantity`}
                      onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                    >
                      <Plus size={15} />
                    </button>
                  </div>
                  <strong className="cart-line-total">
                    {currency.format(item.price * item.quantity)}
                  </strong>
                  <button
                    type="button"
                    className="cart-remove"
                    aria-label={`Remove ${item.title} from cart`}
                    onClick={() => onRemoveItem(item.id)}
                  >
                    <Trash2 size={17} />
                  </button>
                </div>
              </article>
            ))}
          </div>

          <aside className="cart-summary" aria-label="Order summary">
            <p className="eyebrow">SUMMARY</p>
            <div className="cart-summary-row">
              <span>Items ({itemCount})</span>
              <strong>{currency.format(total)}</strong>
            </div>
            <div className="cart-summary-row cart-total-row">
              <span>Total</span>
              <strong>{currency.format(total)}</strong>
            </div>
            <p className="cart-summary-note">Taxes calculated at checkout.</p>
            <Link className="cart-browse cart-checkout" to="/cards">
              <CreditCard size={17} />
              Checkout
            </Link>
            <Link className="cart-browse" to="/discover">
              Continue browsing <ArrowRight size={17} />
            </Link>
          </aside>
        </div>
      )}
    </section>
  );
}

export default Cart;
