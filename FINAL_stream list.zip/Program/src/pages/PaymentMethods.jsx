import { useState } from "react";
import { ArrowLeft, CreditCard, Plus, ShieldCheck, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";

function loadPaymentMethods(storageKey) {
  try {
    const savedMethods = JSON.parse(localStorage.getItem(storageKey) || "[]");
    return Array.isArray(savedMethods)
      ? savedMethods.filter(
          (method) =>
            method &&
            typeof method.id === "string" &&
            typeof method.cardholder === "string" &&
            typeof method.brand === "string" &&
            /^\d{4}$/.test(method.last4) &&
            Number.isInteger(method.expiryMonth) &&
            method.expiryMonth >= 1 &&
            method.expiryMonth <= 12 &&
            Number.isInteger(method.expiryYear),
        )
      : [];
  } catch (error) {
    console.error("Unable to load saved payment methods:", error);
    return [];
  }
}

function formatCardNumber(value) {
  const digits = value.replace(/\D/g, "").slice(0, 16);
  return digits.match(/\d{1,4}/g)?.join(" ") ?? "";
}

function formatExpiry(value) {
  const digits = value.replace(/\D/g, "").slice(0, 4);
  return digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits;
}

function passesLuhnCheck(cardNumber) {
  let sum = 0;
  let shouldDouble = false;

  for (let index = cardNumber.length - 1; index >= 0; index -= 1) {
    let digit = Number(cardNumber[index]);
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

function getCardBrand(cardNumber) {
  if (cardNumber.startsWith("4")) return "Visa";
  if (/^(5[1-5]|2(2[2-9]|[3-6]\d|7[01]|720))/.test(cardNumber)) {
    return "Mastercard";
  }
  if (/^(6011|65|64[4-9])/.test(cardNumber)) return "Discover";
  return "Card";
}

function isExpiryValid(expiry) {
  const match = /^(\d{2})\/(\d{2})$/.exec(expiry);
  if (!match) return false;

  const month = Number(match[1]);
  const year = 2000 + Number(match[2]);
  const now = new Date();

  return (
    month >= 1 &&
    month <= 12 &&
    (year > now.getFullYear() ||
      (year === now.getFullYear() && month >= now.getMonth() + 1))
  );
}

function PaymentMethods({ storageKey }) {
  const [methods, setMethods] = useState(() => loadPaymentMethods(storageKey));
  const [cardholder, setCardholder] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [securityCode, setSecurityCode] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  function persistMethods(nextMethods) {
    try {
      localStorage.setItem(storageKey, JSON.stringify(nextMethods));
      setMethods(nextMethods);
      return true;
    } catch (storageError) {
      console.error("Unable to save payment method:", storageError);
      setError("This browser could not save the card details. Check available storage and try again.");
      return false;
    }
  }

  function handleSubmit(event) {
    event.preventDefault();
    setError("");
    setNotice("");

    if (!cardholder.trim()) {
      setError("Enter the name printed on the card.");
      return;
    }

    const digits = cardNumber.replace(/\D/g, "");
    if (digits.length !== 16 || !passesLuhnCheck(digits)) {
      setError("Enter a valid 16-digit card number.");
      return;
    }

    if (!isExpiryValid(expiry)) {
      setError("Enter a valid, unexpired expiration date in MM/YY format.");
      return;
    }

    if (!/^\d{3,4}$/.test(securityCode)) {
      setError("Enter a 3- or 4-digit security code.");
      return;
    }

    const [expiryMonth, expiryYear] = expiry.split("/").map(Number);
    const nextMethods = [
      ...methods,
      {
        id: crypto.randomUUID(),
        cardholder: cardholder.trim(),
        brand: getCardBrand(digits),
        last4: digits.slice(-4),
        expiryMonth,
        expiryYear: 2000 + expiryYear,
      },
    ];

    if (persistMethods(nextMethods)) {
      setCardholder("");
      setCardNumber("");
      setExpiry("");
      setSecurityCode("");
      setNotice("Card saved in this browser.");
    }
  }

  function removeMethod(id) {
    setError("");
    setNotice("");
    persistMethods(methods.filter((method) => method.id !== id));
  }

  return (
    <section className="page-card payment-page">
      <div className="page-heading payment-heading">
        <CreditCard size={34} />
        <div>
          <p className="eyebrow">SECURE PAYMENT MANAGEMENT</p>
          <h2>Payment Cards</h2>
          <p>Manage the cards associated with your account.</p>
        </div>
      </div>

      <div className="payment-security-note">
        <ShieldCheck size={20} aria-hidden="true" />
        <p>
          This demo stores only the cardholder name, brand, last four digits, and
          expiration date in this browser. Full card numbers and security codes
          are never saved, and no payment is processed.
        </p>
      </div>

      <div className="payment-layout">
        <section className="payment-saved" aria-labelledby="saved-cards-heading">
          <div className="payment-section-heading">
            <h3 id="saved-cards-heading">Saved cards</h3>
            <span>{methods.length}</span>
          </div>

          {methods.length === 0 ? (
            <div className="payment-empty">
              <CreditCard size={28} aria-hidden="true" />
              <p>No payment cards saved yet.</p>
            </div>
          ) : (
            <ul className="payment-card-list">
              {methods.map((method) => (
                <li className="payment-saved-card" key={method.id}>
                  <CreditCard size={24} aria-hidden="true" />
                  <div>
                    <strong>{method.brand} ···· {method.last4}</strong>
                    <span>{method.cardholder}</span>
                    <span>
                      Expires {String(method.expiryMonth).padStart(2, "0")}/
                      {String(method.expiryYear).slice(-2)}
                    </span>
                  </div>
                  <button
                    type="button"
                    className="payment-remove"
                    aria-label={`Remove ${method.brand} ending in ${method.last4}`}
                    onClick={() => removeMethod(method.id)}
                  >
                    <Trash2 size={17} />
                  </button>
                </li>
              ))}
            </ul>
          )}

          <Link className="payment-back-link" to="/cart">
            <ArrowLeft size={16} /> Back to cart
          </Link>
        </section>

        <section className="payment-form-panel" aria-labelledby="add-card-heading">
          <div className="payment-section-heading">
            <h3 id="add-card-heading">Add a card</h3>
            <Plus size={19} aria-hidden="true" />
          </div>

          <form className="payment-form" onSubmit={handleSubmit}>
            <div className="field-group">
              <label htmlFor="cardholder-name">Name on card</label>
              <input
                id="cardholder-name"
                autoComplete="cc-name"
                maxLength={80}
                required
                value={cardholder}
                onChange={(event) => setCardholder(event.target.value)}
              />
            </div>

            <div className="field-group">
              <label htmlFor="card-number">Card number</label>
              <input
                id="card-number"
                type="text"
                inputMode="numeric"
                autoComplete="cc-number"
                placeholder="1234 5678 9012 3456"
                maxLength={19}
                pattern="[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}"
                title="Enter 16 digits in groups of four."
                required
                value={cardNumber}
                onChange={(event) => setCardNumber(formatCardNumber(event.target.value))}
              />
            </div>

            <div className="payment-input-row">
              <div className="field-group">
                <label htmlFor="card-expiry">Expiration</label>
                <input
                  id="card-expiry"
                  type="text"
                  inputMode="numeric"
                  autoComplete="cc-exp"
                  placeholder="MM/YY"
                  maxLength={5}
                  pattern="(0[1-9]|1[0-2])/[0-9]{2}"
                  required
                  value={expiry}
                  onChange={(event) => setExpiry(formatExpiry(event.target.value))}
                />
              </div>

              <div className="field-group">
                <label htmlFor="card-security-code">Security code</label>
                <input
                  id="card-security-code"
                  type="password"
                  inputMode="numeric"
                  autoComplete="cc-csc"
                  maxLength={4}
                  pattern="[0-9]{3,4}"
                  required
                  value={securityCode}
                  onChange={(event) =>
                    setSecurityCode(event.target.value.replace(/\D/g, "").slice(0, 4))
                  }
                />
              </div>
            </div>

            {error && <p className="payment-feedback payment-error" role="alert">{error}</p>}
            {notice && <p className="payment-feedback" role="status">{notice}</p>}

            <button className="login-submit payment-save" type="submit">
              Save card <CreditCard size={18} />
            </button>
          </form>
        </section>
      </div>
    </section>
  );
}

export default PaymentMethods;
