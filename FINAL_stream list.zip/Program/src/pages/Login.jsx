import { useEffect, useRef, useState } from "react";
import { ArrowRight, Eye, EyeOff, LockKeyhole } from "lucide-react";

function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [googleStatus, setGoogleStatus] = useState("");
  const googleButtonRef = useRef(null);

  async function handleSubmit(event) {
    event.preventDefault();
    setError("");
    setIsSubmitting(true);

    try {
      const response = await fetch(
        isRegistering ? "/api/auth/register" : "/api/auth/login",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({ email, password }),
        },
      );
      const result = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error(result?.error || "Unable to reach the authentication server.");
      }

      if (!result?.user) {
        throw new Error("The authentication server returned an invalid response.");
      }

      onLogin(result.user);
    } catch (requestError) {
      setError(requestError.message || "Unable to reach the authentication server.");
    } finally {
      setIsSubmitting(false);
    }
  }

  useEffect(() => {
    let isMounted = true;
    let googleScript;

    async function loadGoogleSignIn() {
      try {
        const response = await fetch("/api/auth/google/config");
        if (!response.ok) {
          throw new Error("Unable to load Google sign-in configuration.");
        }

        const { clientId } = await response.json();
        if (!isMounted) return;

        if (!clientId) {
          setGoogleStatus("Google sign-in needs a GOOGLE_CLIENT_ID in the server .env file.");
          return;
        }

        const renderGoogleButton = () => {
          if (!isMounted || !googleButtonRef.current || !window.google?.accounts?.id) {
            return;
          }

          window.google.accounts.id.initialize({
            client_id: clientId,
            callback: async ({ credential }) => {
              setError("");
              setIsSubmitting(true);

              try {
                const authResponse = await fetch("/api/auth/google", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  credentials: "same-origin",
                  body: JSON.stringify({ credential }),
                });
                const result = await authResponse.json().catch(() => null);

                if (!authResponse.ok) {
                  throw new Error(result?.error || "Google sign-in could not be verified.");
                }

                if (!result?.user) {
                  throw new Error("The authentication server returned an invalid response.");
                }

                onLogin(result.user);
              } catch (requestError) {
                setError(requestError.message || "Google sign-in could not be verified.");
              } finally {
                setIsSubmitting(false);
              }
            },
          });
          window.google.accounts.id.renderButton(googleButtonRef.current, {
            theme: "filled_black",
            size: "large",
            shape: "rectangular",
            text: "continue_with",
            width: 320,
          });
          setGoogleStatus("");
        };

        if (window.google?.accounts?.id) {
          renderGoogleButton();
          return;
        }

        googleScript = document.createElement("script");
        googleScript.src = "https://accounts.google.com/gsi/client";
        googleScript.async = true;
        googleScript.defer = true;
        googleScript.onload = renderGoogleButton;
        googleScript.onerror = () => {
          if (isMounted) setGoogleStatus("Google sign-in could not be loaded. Try again later.");
        };
        document.head.appendChild(googleScript);
      } catch (requestError) {
        if (isMounted) {
          setGoogleStatus(requestError.message || "Google sign-in is unavailable.");
        }
      }
    }

    loadGoogleSignIn();
    return () => {
      isMounted = false;
      googleScript?.remove();
    };
  }, [onLogin]);

  function toggleMode(event) {
    event.preventDefault();
    setIsRegistering((current) => !current);
    setError("");
  }

  return (
    <section className="page-card login-page">
      <div className="page-heading login-heading">
        <LockKeyhole size={34} />

        <div>
          <p className="eyebrow">ACCESS PORTAL</p>
          <h2>{isRegistering ? "Create Account" : "Log In"}</h2>
          <p>
            {isRegistering
              ? "Create an account to secure your stream queue."
              : "Sign in to keep track of your stream queue and watched list."}
          </p>
        </div>
      </div>

      <form className="login-form" onSubmit={handleSubmit}>
        <div className="field-group">
          <label htmlFor="login-email">Email</label>
          <input
            id="login-email"
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
            required
            maxLength={254}
          />
        </div>

        <div className="field-group">
          <label htmlFor="login-password">Password</label>

          <div className="password-wrap">
            <input
              id="login-password"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder={isRegistering ? "At least 12 characters" : "Enter your password"}
              autoComplete={isRegistering ? "new-password" : "current-password"}
              minLength={isRegistering ? 12 : undefined}
              maxLength={72}
              required
            />

            <button
              type="button"
              className="password-toggle"
              onClick={() => setShowPassword((current) => !current)}
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
        </div>

        {error && <p className="login-error" role="alert">{error}</p>}

        <button type="submit" className="login-submit" disabled={isSubmitting}>
          {isSubmitting
            ? "Please wait..."
            : isRegistering
              ? "Create Account"
              : "Log In"}
          {!isSubmitting && <ArrowRight size={18} />}
        </button>
      </form>

      <div className="login-divider"><span>OR</span></div>
      <div className="google-signin">
        <div ref={googleButtonRef} className="google-signin-button" />
        {googleStatus && <p className="google-signin-status" role="status">{googleStatus}</p>}
      </div>

      <p className="login-signup">
        {isRegistering ? "Already have an account? " : "Need an account? "}
        <a href="#account-mode" onClick={toggleMode}>
          {isRegistering ? "Log in" : "Create one"}
        </a>
      </p>
    </section>
  );
}

export default Login;
