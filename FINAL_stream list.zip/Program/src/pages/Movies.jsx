import MediaCatalog from "../components/MediaCatalog";

function Movies({ streamListItems, onAddToStreamList }) {
  return (
    <MediaCatalog
      mediaType="movie"
      streamListItems={streamListItems}
      onAddToStreamList={onAddToStreamList}
    />
  );
}

export default Movies;
