import { useCallback, useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Navigation from "./components/Navigation";
import StreamList from "./pages/StreamList";
import Movies from "./pages/Movies";
import Cart from "./pages/Cart";
import About from "./pages/About";
import Login from "./pages/Login";
import Discover from "./pages/Discover";
import Shows from "./pages/Shows";
import Subscriptions from "./pages/Subscriptions";
import PaymentMethods from "./pages/PaymentMethods";

const STREAM_LIST_KEY = "streamlist-watch-list";

function loadStreamList() {
  try {
    const savedItems = JSON.parse(localStorage.getItem(STREAM_LIST_KEY) || "[]");
    return Array.isArray(savedItems)
      ? savedItems
          .filter(
            (item) =>
              item &&
              (typeof item.id === "string" || typeof item.id === "number") &&
              typeof item.title === "string" &&
              typeof item.completed === "boolean",
          )
          .map((item) => ({
            ...item,
            price: Number.isFinite(item.price) && item.price >= 0 ? item.price : 0,
          }))
      : [];
  } catch {
    return [];
  }
}

function ProtectedRoute({ isLoggedIn, children }) {
  return isLoggedIn ? children : <Navigate to="/login" replace />;
}

function App() {
  const [user, setUser] = useState(undefined);
  const isLoggedIn = Boolean(user);
  const [streamMovies, setStreamMovies] = useState(loadStreamList);
  const [cartItems, setCartItems] = useState(() => {
    try {
      const savedCart = JSON.parse(localStorage.getItem("streamlist-cart") || "[]");
      return Array.isArray(savedCart)
        ? savedCart.filter(
            (item) =>
              item &&
              (typeof item.id === "string" || typeof item.id === "number") &&
              typeof item.title === "string" &&
              Number.isFinite(item.price) &&
              Number.isInteger(item.quantity) &&
              item.quantity > 0,
          )
        : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("streamlist-cart", JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem(STREAM_LIST_KEY, JSON.stringify(streamMovies));
    } catch {}
  }, [streamMovies]);

  useEffect(() => {
    fetch("/api/auth/me", { credentials: "same-origin" })
      .then((response) => (response.ok ? response.json() : null))
      .then((result) => setUser(result?.user ?? null))
      .catch(() => setUser(null));
  }, []);

  const handleLogin = useCallback((authenticatedUser) => {
    setUser(authenticatedUser);
  }, []);

  function addToCart(product) {
    setCartItems((currentItems) => {
      const existingItem = currentItems.find((item) => item.id === product.id);

      if (existingItem) {
        return currentItems.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item,
        );
      }

      return [...currentItems, { ...product, quantity: 1 }];
    });
  }

  function addToStreamList(item) {
    setStreamMovies((currentItems) =>
      currentItems.some((currentItem) => currentItem.id === item.id)
        ? currentItems
        : [...currentItems, item],
    );
  }

  function removeFromStreamList(id) {
    setStreamMovies((currentItems) => currentItems.filter((item) => item.id !== id));
  }

  function toggleStreamListItem(id) {
    setStreamMovies((currentItems) =>
      currentItems.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item,
      ),
    );
  }

  function renameStreamListItem(id, title) {
    setStreamMovies((currentItems) =>
      currentItems.map((item) => (item.id === id ? { ...item, title } : item)),
    );
  }

  function updateCartQuantity(id, quantity) {
    const sanitizedQuantity = Number.isFinite(quantity) ? Math.trunc(quantity) : 1;

    setCartItems((currentItems) =>
      currentItems
        .map((item) =>
          item.id === id ? { ...item, quantity: Math.max(1, sanitizedQuantity) } : item,
        )
        .filter((item) => item.quantity > 0),
    );
  }

  function removeFromCart(id) {
    setCartItems((currentItems) => currentItems.filter((item) => item.id !== id));
  }

  async function handleLogout() {
    const response = await fetch("/api/auth/logout", {
      method: "POST",
      credentials: "same-origin",
    });

    if (response.ok) {
      setUser(null);
    }
  }

  if (user === undefined) {
    return (
      <div className="app-shell">
        <main className="page-area" role="status">Checking session...</main>
      </div>
    );
  }

  return (
    <div className="app-shell">
      {isLoggedIn && (
        <Navigation
          onLogout={handleLogout}
          cartCount={cartItems.reduce((total, item) => total + item.quantity, 0)}
        />
      )}

      <main className="page-area">
        <Routes>
          <Route
            path="/"
            element={<Navigate to={isLoggedIn ? "/streamlist" : "/login"} replace />}
          />

          <Route
            path="/streamlist"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <StreamList
                  movies={streamMovies}
                  onAddMovie={addToStreamList}
                  onDeleteMovie={removeFromStreamList}
                  onToggleMovie={toggleStreamListItem}
                  onRenameMovie={renameStreamListItem}
                />
              </ProtectedRoute>
            }
          />

          <Route
            path="/movies"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <Movies
                  streamListItems={streamMovies}
                  onAddToStreamList={addToStreamList}
                />
              </ProtectedRoute>
            }
          />

          <Route
            path="/shows"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <Shows
                  streamListItems={streamMovies}
                  onAddToStreamList={addToStreamList}
                />
              </ProtectedRoute>
            }
          />

          <Route
            path="/discover"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <Discover cartItems={cartItems} onAddToCart={addToCart} />
              </ProtectedRoute>
            }
          />

          <Route
            path="/subscriptions"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <Subscriptions />
              </ProtectedRoute>
            }
          />

          <Route
            path="/cart"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <Cart
                  cartItems={cartItems}
                  onUpdateQuantity={updateCartQuantity}
                  onRemoveItem={removeFromCart}
                  onClearCart={() => setCartItems([])}
                />
              </ProtectedRoute>
            }
          />

          <Route
            path="/cards"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <PaymentMethods
                  storageKey={`streamlist-payment-methods:${user?.id ?? "unknown"}`}
                />
              </ProtectedRoute>
            }
          />

          <Route
            path="/about"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <About />
              </ProtectedRoute>
            }
          />

          <Route
            path="/login"
            element={
              isLoggedIn ? (
                <Navigate to="/streamlist" replace />
              ) : (
                <Login onLogin={handleLogin} />
              )
            }
          />

          <Route
            path="*"
            element={<Navigate to={isLoggedIn ? "/streamlist" : "/login"} replace />}
          />
        </Routes>
      </main>

      <footer className="footer">
        <p>StreamList • EZTechMovie</p>
      </footer>
    </div>
  );
}

export default App;
