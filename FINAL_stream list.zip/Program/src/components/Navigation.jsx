import { NavLink } from "react-router-dom";
import { ListVideo, Film, ShoppingCart, Info, Search, LogOut, Tv, CreditCard } from "lucide-react";

function Navigation({ onLogout, cartCount }) {
  const getLinkClass = ({ isActive }) =>
    isActive ? "nav-link active" : "nav-link";

  return (
    <header className="top-bar">
      <div className="brand">
        <div className="brand-logo" aria-label="StreamList logo">
          <div className="logo-control">
            <div className="logo-circle logo-play">
              <span className="play-triangle" aria-hidden="true" />
            </div>
            <span className="logo-label">PLAY</span>
          </div>

          <div className="logo-control">
            <div className="logo-circle logo-pause">
              <span className="pause-bars" aria-hidden="true">
                <span />
                <span />
              </span>
            </div>
            <span className="logo-label">PAUSE</span>
          </div>

          <div className="logo-control">
            <div className="logo-circle logo-stop">
              <span className="stop-square" aria-hidden="true" />
            </div>
            <span className="logo-label">STOP</span>
          </div>
        </div>

        <div className="brand-text">
          <h1>Stream List</h1>
          <span>by EZTechMovie</span>
        </div>
      </div>

      <nav className="nav-menu" aria-label="Main navigation">
        <NavLink to="/streamlist" end className={getLinkClass}>
          <ListVideo size={18} />
          Stream List
        </NavLink>

        <NavLink to="/movies" className={getLinkClass}>
          <Film size={18} />
          Movies
        </NavLink>

        <NavLink to="/shows" className={getLinkClass}>
          <Tv size={18} />
          TV Shows
        </NavLink>

        <NavLink to="/discover" className={getLinkClass}>
          <Search size={18} />
          Discover
        </NavLink>

        <NavLink to="/cart" className={getLinkClass}>
          <ShoppingCart size={18} />
          Cart
          {cartCount > 0 && <span className="nav-cart-count">{cartCount}</span>}
        </NavLink>

        <NavLink to="/cards" className={getLinkClass}>
          <CreditCard size={18} />
          Payment Cards
        </NavLink>

        <NavLink to="/subscriptions" className={getLinkClass}>
          <CreditCard size={18} />
          Subscriptions
        </NavLink>

        <NavLink to="/about" className={getLinkClass}>
          <Info size={18} />
          About
        </NavLink>

        <button type="button" className="nav-link nav-logout" onClick={onLogout}>
          <LogOut size={18} />
          Sign Out
        </button>
      </nav>
    </header>
  );
}

export default Navigation;
