import { useEffect, useState } from "react";
import { CalendarDays, Check, Clapperboard, Film, Plus, Search, Star, Tv } from "lucide-react";

const API_KEY = import.meta.env.VITE_TMDB_API_KEY;
const API_BASE = "https://api.themoviedb.org/3";
const IMAGE_BASE = "https://image.tmdb.org/t/p/w500";

function getRentalPrice(rating) {
  if (!Number.isFinite(rating)) {
    return 0;
  }

  if (rating >= 9) {
    return 3.99;
  }

  return rating >= 7.5 ? 1.99 : 0;
}

const catalogTypes = {
  movie: {
    label: "Movies",
    singular: "movie",
    popularEndpoint: "/movie/popular",
    searchEndpoint: "/search/movie",
    dateField: "release_date",
    Icon: Film,
  },
  tv: {
    label: "TV Shows",
    singular: "TV show",
    popularEndpoint: "/tv/popular",
    searchEndpoint: "/search/tv",
    dateField: "first_air_date",
    Icon: Tv,
  },
};

function MediaCatalog({ mediaType, streamListItems, onAddToStreamList }) {
  const config = catalogTypes[mediaType];
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState("");
  const [activeQuery, setActiveQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const Icon = config.Icon;

  useEffect(() => {
    if (!API_KEY) {
      setLoading(false);
      return undefined;
    }

    const controller = new AbortController();
    const endpoint = activeQuery
      ? `${config.searchEndpoint}?query=${encodeURIComponent(activeQuery)}`
      : config.popularEndpoint;

    async function loadCatalog() {
      setLoading(true);
      setError("");

      try {
        const separator = endpoint.includes("?") ? "&" : "?";
        const response = await fetch(`${API_BASE}${endpoint}${separator}api_key=${API_KEY}`, {
          signal: controller.signal,
        });

        if (!response.ok) {
          throw new Error(
            response.status === 401
              ? "TMDB rejected the API key. Check your VITE_TMDB_API_KEY value."
              : `TMDB request failed (${response.status}). Please try again.`,
          );
        }

        const data = await response.json();
        setItems(Array.isArray(data.results) ? data.results : []);
      } catch (requestError) {
        if (requestError.name !== "AbortError") {
          setError(requestError.message || `Unable to load ${config.label.toLowerCase()}.`);
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    loadCatalog();
    return () => controller.abort();
  }, [activeQuery, config]);

  function handleSearch(event) {
    event.preventDefault();
    setActiveQuery(query.trim());
  }

  return (
    <section className="page-card catalog-page">
      <div className="page-heading">
        <Icon size={34} />
        <div>
          <p className="eyebrow">POWERED BY TMDB</p>
          <h2>{config.label}</h2>
          <p>Browse popular {config.label.toLowerCase()} or search the catalog.</p>
        </div>
      </div>

      <form className="discover-search" onSubmit={handleSearch}>
        <label className="sr-only" htmlFor={`${mediaType}-search`}>
          Search {config.label.toLowerCase()}
        </label>
        <input
          id={`${mediaType}-search`}
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder={`Search ${config.singular} titles`}
        />
        <button type="submit" aria-label={`Search ${config.label}`}>
          <Search size={18} />
          Search
        </button>
      </form>

      <div className="discover-results-heading">
        <h3>{activeQuery ? `Results for “${activeQuery}”` : `Popular ${config.label.toLowerCase()}`}</h3>
        <span>{loading ? "Loading" : `${items.length} titles`}</span>
      </div>

      {!API_KEY ? (
        <p className="discover-message" role="status">
          Add your TMDB API key as <code>VITE_TMDB_API_KEY</code> in a local
          <code> .env</code> file, then restart the development server.
        </p>
      ) : loading ? (
        <p className="discover-message" role="status">Loading {config.label.toLowerCase()} from TMDB...</p>
      ) : error ? (
        <p className="discover-message discover-error" role="alert">{error}</p>
      ) : items.length === 0 ? (
        <p className="discover-message" role="status">No results. Try another title.</p>
      ) : (
        <div className="discover-grid">
          {items.map((item) => {
            const title = item.title || item.name;
            const releaseDate = item[config.dateField];
            const rating = Number(item.vote_average);
            const price = getRentalPrice(rating);
            const streamListId = `tmdb-${mediaType}-${item.id}`;
            const isAdded = streamListItems.some((listItem) => listItem.id === streamListId);

            return (
              <article className="discover-movie" key={item.id}>
                {item.poster_path ? (
                  <img
                    className="discover-poster"
                    src={`${IMAGE_BASE}${item.poster_path}`}
                    alt={`${title} poster`}
                    loading="lazy"
                  />
                ) : (
                  <div className="discover-poster poster-placeholder" aria-label="No poster available">
                    <Clapperboard size={32} />
                    <span>No poster</span>
                  </div>
                )}
                <div className="discover-movie-info">
                  <h4>{title}</h4>
                  <div className="discover-meta">
                    {releaseDate && (
                      <span><CalendarDays size={14} />{releaseDate.slice(0, 4)}</span>
                    )}
                    <span><Star size={14} />{Number.isFinite(rating) ? rating.toFixed(1) : "N/A"}</span>
                  </div>
                  <p>{item.overview || "No overview available."}</p>
                  <div className="discover-purchase">
                    <strong className={price === 0 ? "free-price" : ""}>
                      {price === 0 ? "Free" : `$${price.toFixed(2)}`}
                    </strong>
                    <button
                      type="button"
                      disabled={isAdded}
                      aria-label={isAdded ? `${title} is in StreamList` : `Add ${title} to StreamList`}
                      onClick={() =>
                        onAddToStreamList({
                          id: streamListId,
                          title,
                          completed: false,
                          price,
                          mediaType,
                          year: releaseDate?.slice(0, 4) || "",
                        })
                      }
                    >
                      {isAdded ? <Check size={16} /> : <Plus size={16} />}
                      {isAdded ? "Added" : "Add"}
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      <p className="tmdb-attribution">Movie and TV data and images courtesy of TMDB.</p>
    </section>
  );
}

export default MediaCatalog;
