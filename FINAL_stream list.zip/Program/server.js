import "dotenv/config";
import express from "express";
import session from "express-session";
import bcrypt from "bcryptjs";
import { OAuth2Client } from "google-auth-library";
import { rateLimit } from "express-rate-limit";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const currentDirectory = path.dirname(fileURLToPath(import.meta.url));
const usersFile = process.env.AUTH_DATA_FILE
  ? path.resolve(process.env.AUTH_DATA_FILE)
  : path.join(currentDirectory, ".auth-data", "users.json");
const isProduction = process.env.NODE_ENV === "production";
const port = Number(process.env.PORT || 3001);
const googleClientId = process.env.GOOGLE_CLIENT_ID?.trim() || "";
const googleAuthClient = googleClientId ? new OAuth2Client(googleClientId) : null;

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("Set SESSION_SECRET to a random value of at least 32 characters.");
}

function readUsers() {
  if (!fs.existsSync(usersFile)) {
    return [];
  }

  try {
    const rawUsers = fs.readFileSync(usersFile, "utf8");
    const parsedUsers = JSON.parse(rawUsers);
    return Array.isArray(parsedUsers) ? parsedUsers : [];
  } catch {
    return [];
  }
}

function writeUsers(users) {
  fs.mkdirSync(path.dirname(usersFile), { recursive: true });
  const temporaryFile = `${usersFile}.${process.pid}.tmp`;
  fs.writeFileSync(temporaryFile, JSON.stringify(users, null, 2), { mode: 0o600 });
  fs.renameSync(temporaryFile, usersFile);
}

function publicUser(user) {
  return { id: user.id, email: user.email };
}

function startSession(request, response, user) {
  request.session.regenerate((error) => {
    if (error) {
      return response.status(500).json({ error: "Unable to start a session." });
    }

    request.session.user = publicUser(user);
    request.session.save((saveError) => {
      if (saveError) {
        return response.status(500).json({ error: "Unable to save the session." });
      }

      return response.json({ user: request.session.user });
    });
  });
}

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "10kb" }));
app.use(
  session({
    name: "streamlist.sid",
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "strict",
      secure: isProduction,
      maxAge: 1000 * 60 * 60 * 24 * 7,
    },
  }),
);

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many attempts. Please try again in 15 minutes." },
});

app.post("/api/auth/register", authLimiter, async (request, response) => {
  const email = typeof request.body.email === "string"
    ? request.body.email.trim().toLowerCase()
    : "";
  const password = typeof request.body.password === "string" ? request.body.password : "";
  const passwordBytes = Buffer.byteLength(password, "utf8");

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return response.status(400).json({ error: "Enter a valid email address." });
  }

  if (passwordBytes < 12 || passwordBytes > 72) {
    return response.status(400).json({
      error: "Use a password between 12 and 72 UTF-8 bytes long.",
    });
  }

  const users = readUsers();
  if (users.some((user) => user.email === email)) {
    return response.status(409).json({ error: "An account with this email already exists." });
  }

  const user = {
    id: randomUUID(),
    email,
    passwordHash: await bcrypt.hash(password, 12),
  };

  writeUsers([...users, user]);
  return startSession(request, response, user);
});

app.post("/api/auth/login", authLimiter, async (request, response) => {
  const email = typeof request.body.email === "string"
    ? request.body.email.trim().toLowerCase()
    : "";
  const password = typeof request.body.password === "string" ? request.body.password : "";
  const user = readUsers().find((candidate) => candidate.email === email);

  if (!user?.passwordHash || !(await bcrypt.compare(password, user.passwordHash))) {
    return response.status(401).json({ error: "Email or password is incorrect." });
  }

  return startSession(request, response, user);
});

app.get("/api/auth/google/config", (_request, response) => {
  return response.json({ clientId: googleClientId });
});

app.post("/api/auth/google", authLimiter, async (request, response) => {
  const credential =
    typeof request.body.credential === "string" ? request.body.credential : "";

  if (!googleAuthClient) {
    return response.status(503).json({ error: "Google sign-in is not configured." });
  }

  if (!credential || credential.length > 8192) {
    return response.status(400).json({ error: "A valid Google credential is required." });
  }

  let payload;
  try {
    const ticket = await googleAuthClient.verifyIdToken({
      idToken: credential,
      audience: googleClientId,
    });
    payload = ticket.getPayload();
  } catch {
    return response.status(401).json({ error: "Google could not verify this sign-in." });
  }

  if (!payload?.sub || !payload.email || payload.email_verified !== true) {
    return response.status(401).json({ error: "Google could not verify this sign-in." });
  }

  const email = payload.email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return response.status(401).json({ error: "Google could not verify this sign-in." });
  }

  const users = readUsers();
  let user = users.find((candidate) => candidate.googleSub === payload.sub);
  if (!user) {
    user = users.find((candidate) => candidate.email === email);
    if (user?.googleSub && user.googleSub !== payload.sub) {
      return response.status(409).json({
        error: "This email is already linked to another Google account.",
      });
    }

    if (user) {
      user.googleSub = payload.sub;
    } else {
      user = { id: randomUUID(), email, googleSub: payload.sub };
      users.push(user);
    }

    writeUsers(users);
  }

  return startSession(request, response, user);
});

app.get("/api/auth/me", (request, response) => {
  return response.json({ user: request.session.user ?? null });
});

app.post("/api/auth/logout", (request, response) => {
  request.session.destroy((error) => {
    if (error) {
      return response.status(500).json({ error: "Unable to sign out." });
    }

    response.clearCookie("streamlist.sid", {
      httpOnly: true,
      sameSite: "strict",
      secure: isProduction,
    });
    return response.sendStatus(204);
  });
});

app.use(express.static(path.join(currentDirectory, "dist")));
app.get(/.*/, (_request, response, next) => {
  const indexFile = path.join(currentDirectory, "dist", "index.html");
  if (!fs.existsSync(indexFile)) {
    return next();
  }

  return response.sendFile(indexFile);
});

app.listen(port, () => {
  console.log(`StreamList server listening on http://localhost:${port}`);
});