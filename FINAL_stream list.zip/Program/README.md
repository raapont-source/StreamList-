
```bash
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
npm install
npm run dev
```
run this in order
npm run dev:server
npm run dev

local log in 
username: hello@gmail.com
PASSWORD: 1qaz2wsx!QAZ@WSX