import { ShoppingCart } from "lucide-react";

function Cart() {
  return (
    <section className="page-card empty-page">
      <ShoppingCart size={46} />
      <h2>Cart</h2>
      <p>This page is reserved for Week 4.</p>
    </section>
  );
}

export default Cart;
