import { Info, Clapperboard, Film, ShoppingCart } from "lucide-react";

function About() {
  return (
    <section className="page-card">
      <div className="page-heading">
        <Info size={34} />
        <div>
          <p className="eyebrow">ABOUT EZTECHMOVIE</p>
          <h2>About Stream List</h2>
        </div>
      </div>

      <div style={{ marginTop: "28px", display: "grid", gap: "16px" }}>
        <div
          style={{
            background: "#0d1728",
            border: "1px solid #26334c",
            borderRadius: "12px",
            padding: "18px",
          }}
        >
          <Clapperboard size={20} style={{ marginBottom: "8px" }} />
          <h3 style={{ margin: "0 0 8px" }}>Personal watch list</h3>
          <p style={{ margin: 0, color: "#aebbd1", lineHeight: 1.6 }}>
            Users can add titles they want to watch later and keep track of
            their own streaming interests.
          </p>
        </div>

        <div
          style={{
            background: "#0d1728",
            border: "1px solid #26334c",
            borderRadius: "12px",
            padding: "18px",
          }}
        >
          <Film size={20} style={{ marginBottom: "8px" }} />
          <h3 style={{ margin: "0 0 8px" }}>Movie browsing</h3>
          <p style={{ margin: 0, color: "#aebbd1", lineHeight: 1.6 }}>
            The Movies section gives the app a place to organize titles and
            showcases how the interface can grow into a fuller catalog.
          </p>
        </div>

        <div
          style={{
            background: "#0d1728",
            border: "1px solid #26334c",
            borderRadius: "12px",
            padding: "18px",
          }}
        >
          <ShoppingCart size={20} style={{ marginBottom: "8px" }} />
          <h3 style={{ margin: "0 0 8px" }}>Cart-ready structure</h3>
          <p style={{ margin: 0, color: "#aebbd1", lineHeight: 1.6 }}>
            StreamList is organized with future cart and account features in
            mind, making it easy to expand the app over time.
          </p>
        </div>
      </div>
    </section>
  );
}

export default About;
