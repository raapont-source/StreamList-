import { Film } from "lucide-react";

function Movies() {
  return (
    <section className="page-card empty-page">
      <Film size={46} />
      <h2>Movies</h2>
      <p>This page is reserved for Week 4.</p>
    </section>
  );
}

export default Movies;
