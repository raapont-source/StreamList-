import { useState } from "react";
import { Plus, Clapperboard } from "lucide-react";

function StreamList() {
  const [title, setTitle] = useState("");

  function handleSubmit(event) {
    event.preventDefault();

    const cleanedTitle = title.trim();

    if (cleanedTitle === "") {
      console.log("No movie or program was entered.");
      return;
    }

    console.log("StreamList entry:", cleanedTitle);
    setTitle("");
  }

  return (
    <section className="page-card">
      <div className="page-heading">
        <Clapperboard size={34} />
        <div>
          <p className="eyebrow">MY WATCH LIST</p>
          <h2>Stream List</h2>
          <p>
            Enter a movie or program you want to watch. This week's version
            sends the user's entry to the browser console.
          </p>
        </div>
      </div>

      <form className="stream-form" onSubmit={handleSubmit}>
        <label htmlFor="stream-title">Movie or program title</label>

        <div className="input-row">
          <input
            id="stream-title"
            type="text"
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Example: The Mandalorian"
          />

          <button type="submit">
            <Plus size={18} />
            Add to Console
          </button>
        </div>
      </form>

    </section>
  );
}

export default StreamList;
